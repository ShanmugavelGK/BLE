package com.example.ble.utli;

import android.util.Log;

public class Util {

    public static void log(String msg) {
        Log.d("Debug", msg);
    }

    public static void logError(String msg) {
        Log.d("error", msg);
    }

}
